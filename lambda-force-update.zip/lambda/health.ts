import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { createResponse } from './shared/utils';

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  try {
    // Try to connect to Aurora database
    const auroraService = require('../../services/auroraService');
    await auroraService.initialize();

    const healthStatus = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      requestId: context.awsRequestId,
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'production',
      database: 'connected',
      region: process.env.AWS_REGION || 'unknown',
    };

    return createResponse(200, healthStatus);
  } catch (error) {
    console.error('Health check failed:', error);
    
    const healthStatus = {
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      requestId: context.awsRequestId,
      error: error instanceof Error ? error.message : 'Unknown error',
      database: 'disconnected',
    };

    return createResponse(503, healthStatus);
  }
}; 