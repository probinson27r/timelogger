import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { createResponse, logLambdaEvent } from './shared/utils';

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  logLambdaEvent(event, context);

  try {
    // Initialize Aurora database service
    const auroraService = require('../../services/auroraService');
    
    console.log('Starting database migration...');
    
    // Create tables
    await auroraService.createTables();
    
    const result = {
      status: 'success',
      message: 'Database migration completed successfully',
      timestamp: new Date().toISOString(),
      requestId: context.awsRequestId,
      tables: ['user_configs', 'time_logs'],
    };

    console.log('Database migration completed:', result);
    return createResponse(200, result);

  } catch (error) {
    console.error('Database migration failed:', error);
    
    const result = {
      status: 'error',
      message: 'Database migration failed',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString(),
      requestId: context.awsRequestId,
    };

    return createResponse(500, result);
  }
}; 