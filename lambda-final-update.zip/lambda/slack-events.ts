import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { getAppSecrets, createResponse, parseSlackBody, logLambdaEvent } from './shared/utils';

// Import your existing handlers - we'll need to adapt them
const messageHandler = require('../../handlers/messageHandler');

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  logLambdaEvent(event, context);

  try {
    // Get app secrets
    const secrets = await getAppSecrets();
    
    // Set environment variables for existing code compatibility
    process.env.SLACK_BOT_TOKEN = secrets.SLACK_BOT_TOKEN;
    process.env.SLACK_SIGNING_SECRET = secrets.SLACK_SIGNING_SECRET;
    process.env.OPENAI_API_KEY = secrets.OPENAI_API_KEY;
    process.env.ENCRYPTION_KEY = secrets.ENCRYPTION_KEY;

    if (!event.body) {
      return createResponse(400, { error: 'No body provided' });
    }

    const body = parseSlackBody(event.body);
    
    // Handle Slack URL verification challenge
    if (body.type === 'url_verification') {
      return createResponse(200, { challenge: body.challenge });
    }

    // Handle Slack events
    if (body.type === 'event_callback') {
      const slackEvent = body.event;
      
      // Ignore bot messages and message edits
      if (slackEvent.bot_id || slackEvent.subtype === 'message_changed') {
        return createResponse(200, { message: 'Ignored bot or edited message' });
      }

      // Handle app mentions
      if (slackEvent.type === 'app_mention') {
        console.log('Processing app mention:', slackEvent);
        
        // Extract the message text without the bot mention
        const text = slackEvent.text.replace(/<@[^>]+>/, '').trim();
        
        // Create a mock request object for existing handler
        const mockReq = {
          body: {
            event: slackEvent,
            team_id: body.team_id,
          }
        };

        // Use existing message handler
        await messageHandler.handleMessage(mockReq);
        
        return createResponse(200, { message: 'Message processed' });
      }

      // Handle direct messages
      if (slackEvent.type === 'message' && slackEvent.channel_type === 'im') {
        console.log('Processing direct message:', slackEvent);
        
        // Create a mock request object for existing handler
        const mockReq = {
          body: {
            event: slackEvent,
            team_id: body.team_id,
          }
        };

        // Use existing message handler
        await messageHandler.handleMessage(mockReq);
        
        return createResponse(200, { message: 'Direct message processed' });
      }
    }

    return createResponse(200, { message: 'Event received' });

  } catch (error) {
    console.error('Error processing Slack event:', error);
    return createResponse(500, { 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}; 